

class BaseKingAdmin(object):
    list_display = []
    list_filter = []
    search_fields = []